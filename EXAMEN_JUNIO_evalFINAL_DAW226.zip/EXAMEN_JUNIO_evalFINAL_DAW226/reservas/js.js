addEventListener('load',inicio,false)
